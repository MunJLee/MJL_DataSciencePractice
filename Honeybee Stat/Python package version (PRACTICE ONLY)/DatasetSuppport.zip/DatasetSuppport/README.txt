NOTE:

Although this is created in standard python package file structure,
the file content here are expected to be used by Python notebook.


Please upload the following files and do so first before running my final project.

Provider.py
honey.csv
stressors.csv
vHoneyNeonic_v03.csv



